<?php
$server = "localhost";
$user = "root";
$password = "";
$database = "dbbukutamu";

$koneksi = mysqli_connect($server, $user, $password, $database);

if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

$queryCreateTableTamu = "
    CREATE TABLE IF NOT EXISTS ttamu (
        id INT AUTO_INCREMENT PRIMARY KEY,
        tanggal DATE,
        nama VARCHAR(255),
        alamat VARCHAR(255),
        tujuan VARCHAR(255),
        nope VARCHAR(20)
    )
";

if (mysqli_query($koneksi, $queryCreateTableTamu)) {
    echo "";
} else {
    echo "Error creating table 'ttamu': " . mysqli_error($koneksi);
}

$queryCreateTableUser = "
    CREATE TABLE IF NOT EXISTS tuser (
        id INT AUTO_INCREMENT PRIMARY KEY,
        tanggal DATE,
        nama VARCHAR(255),
        alamat VARCHAR(255),
        tujuan VARCHAR(255),
        nope VARCHAR(20)
    )
";

if (mysqli_query($koneksi, $queryCreateTableUser)) {
    echo "";
} else {
    echo "Error creating table 'tuser': " . mysqli_error($koneksi);
}
?>





